## GraphPrompt: Biomedical Entity Normalization Using Graph-based Prompt Templates
This is the dataset of our ACL 2022 paper:

**GraphPrompt: Biomedical Entity Normalization Using Graph-based Prompt Templates**. 

author

Please cite our paper when you use this dataset in your work.


The datasets are from http://www.obofoundry.org/. This website consists of hundreds of sub-datasets that list the [Term] information and its synonym labels and we collect 93 of them. The [Term]s are divided into different files depending on their corresponding biomedical domain. The synonym entries are labeled data and their labels are corresponding [Term] name for entity normalization task. Also, there exist several kinds of relations between [Term]s, which could form a DAG and be utilized for experiments.

Each directory in ```dataset``` corresponds to a biomedical subdiscipline (a DAG). There are two files in each directory: name.txt, and graph.json.

- name.txt: 

Each line in ```name.txt``` is a terminology and its related synonyms which are separated by '\t'.

- graph.json:

graph.json stores the edge information dictionary of the DAG. Each dictionary which represents one directed edge in DAG, consists of three keys, namely "head","relation" and "tail" respectively. For example, {"head": "1st arch mandibular component", "relation": "is_a", "tail": "anatomical entity"} means "1st arch mandibular component" is a "anatomical entity".

All the dictionary shares the rel2template.json, which maps relations among entity names to the templates of Prompt

Since the dataset is large, we suggest you choose part of it to conduct experiments. We use the following ones: cl, hp, mp, doid, fbbt, which are all important in the biomedical domain.

<div id="obo"></div>

- [1] Smith B, Ashburner M, Rosse C, et al. The OBO Foundry: coordinated evolution of ontologies to support biomedical data integration[J]. Nature biotechnology, 2007, 25(11): 1251-1255.